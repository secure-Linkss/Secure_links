import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { 
  Activity, 
  RefreshCw, 
  Search, 
  MapPin, 
  Monitor, 
  Smartphone, 
  Tablet,
  Globe,
  Shield,
  Eye,
  MousePointer,
  Clock,
  Mail,
  Wifi,
  ExternalLink,
  Copy
} from 'lucide-react'

const LiveActivity = () => {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [autoRefresh, setAutoRefresh] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [eventFilter, setEventFilter] = useState('all')
  const [lastUpdated, setLastUpdated] = useState(new Date())

  useEffect(() => {
    fetchEvents()
    
    let interval
    if (autoRefresh) {
      interval = setInterval(fetchEvents, 5000) // Refresh every 5 seconds
    }
    
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [autoRefresh])

  const fetchEvents = async () => {
    try {
      const response = await fetch('/api/events', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setEvents(data.events || [])
        setLastUpdated(new Date())
      } else {
        console.error('Failed to fetch events')
        setEvents([])
        setLastUpdated(new Date())
      }
    } catch (error) {
      console.error('Error fetching events:', error)
      setEvents([])
      setLastUpdated(new Date())
    } finally {
      setLoading(false)
    }
  }

  const mockEvents = [
    {
      id: 1,
      uniqueId: 'uid_abc123_001',
      timestamp: '2024-01-15 14:30:25',
      ip: '192.168.1.100',
      location: 'New York, NY 10001, United States',
      zipCode: '10001',
      region: 'New York',
      country: 'United States',
      city: 'New York',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      browser: 'Chrome 120.0.0.0',
      os: 'Windows 10',
      device: 'Desktop',
      status: 'On Page',
      detailedStatus: 'User landed on target page and is actively browsing',
      linkId: 'abc123',
      campaignId: 'camp_001',
      referrer: 'https://google.com/search?q=example',
      isp: 'Comcast Corporation',
      ispDetails: 'Comcast Cable Communications, LLC',
      emailCaptured: 'john.doe@example.com',
      conversionValue: 25.99,
      sessionDuration: '00:02:45'
    },
    {
      id: 2,
      uniqueId: 'uid_xyz789_002',
      timestamp: '2024-01-15 14:28:15',
      ip: '10.0.0.50',
      location: 'London, SW1A 1AA, United Kingdom',
      zipCode: 'SW1A 1AA',
      region: 'England',
      country: 'United Kingdom',
      city: 'London',
      userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      browser: 'Chrome 120.0.0.0',
      os: 'macOS 10.15.7',
      device: 'Desktop',
      status: 'Redirected',
      detailedStatus: 'User clicked link and was successfully redirected to target page',
      linkId: 'xyz789',
      campaignId: 'camp_002',
      referrer: 'direct',
      isp: 'British Telecom PLC',
      ispDetails: 'BT Group PLC - Business Internet Services',
      emailCaptured: 'jane.smith@company.co.uk',
      conversionValue: 0,
      sessionDuration: '00:01:20'
    },
    {
      id: 3,
      uniqueId: 'uid_def456_003',
      timestamp: '2024-01-15 14:25:45',
      ip: '172.16.0.200',
      location: 'Toronto, ON M5H 2N2, Canada',
      zipCode: 'M5H 2N2',
      region: 'Ontario',
      country: 'Canada',
      city: 'Toronto',
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
      browser: 'Safari 17.0',
      os: 'iOS 17.0',
      device: 'iPhone',
      status: 'Open',
      detailedStatus: 'Email opened, tracking pixel loaded successfully',
      linkId: 'def456',
      campaignId: 'camp_001',
      referrer: 'https://facebook.com/ads/click',
      isp: 'Rogers Communications Inc.',
      ispDetails: 'Rogers Communications Canada Inc. - Wireless Division',
      emailCaptured: 'mike.wilson@rogers.ca',
      conversionValue: 15.50,
      sessionDuration: '00:00:45'
    },
    {
      id: 4,
      uniqueId: 'uid_ghi789_004',
      timestamp: '2024-01-15 14:20:30',
      ip: '203.0.113.45',
      location: 'Sydney, NSW 2000, Australia',
      zipCode: '2000',
      region: 'New South Wales',
      country: 'Australia',
      city: 'Sydney',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
      browser: 'Firefox 120.0',
      os: 'Windows 10',
      device: 'Desktop',
      status: 'On Page',
      detailedStatus: 'User actively browsing target page, multiple page views detected',
      linkId: 'ghi789',
      campaignId: 'camp_003',
      referrer: 'https://linkedin.com/feed',
      isp: 'Telstra Corporation Limited',
      ispDetails: 'Telstra Corporation Limited - Business Internet Services',
      emailCaptured: 'sarah.jones@telstra.com.au',
      conversionValue: 99.99,
      sessionDuration: '00:05:12'
    },
    {
      id: 5,
      uniqueId: 'uid_jkl012_005',
      timestamp: '2024-01-15 14:15:10',
      ip: '198.51.100.25',
      location: 'Berlin, 10115, Germany',
      zipCode: '10115',
      region: 'Berlin',
      country: 'Germany',
      city: 'Berlin',
      userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      browser: 'Chrome 120.0.0.0',
      os: 'Linux',
      device: 'Desktop',
      status: 'Open',
      detailedStatus: 'Email opened via tracking pixel, no click-through yet',
      linkId: 'jkl012',
      campaignId: 'camp_002',
      referrer: 'email',
      isp: 'Deutsche Telekom AG',
      ispDetails: 'Deutsche Telekom AG - T-Online Internet Services',
      emailCaptured: 'hans.mueller@t-online.de',
      conversionValue: 0,
      sessionDuration: '00:00:15'
    }
  ]

  const getStatusBadge = (status) => {
    const statusConfig = {
      'Open': { color: 'bg-blue-600', text: 'Open', icon: Eye },
      'Redirected': { color: 'bg-yellow-600', text: 'Redirected', icon: MousePointer },
      'On Page': { color: 'bg-green-600', text: 'On Page', icon: Globe },
      'Blocked': { color: 'bg-red-600', text: 'Blocked', icon: Shield },
      'Bot': { color: 'bg-purple-600', text: 'Bot', icon: Shield }
    }
    
    const config = statusConfig[status] || statusConfig['Open']
    const Icon = config.icon
    
    return (
      <Badge className={`${config.color} text-white flex items-center gap-1`}>
        <Icon className="h-3 w-3" />
        {config.text}
      </Badge>
    )
  }

  const getDeviceIcon = (device) => {
    switch (device?.toLowerCase()) {
      case 'iphone':
      case 'android':
      case 'mobile':
        return <Smartphone className="h-4 w-4 text-green-400" />
      case 'tablet':
      case 'ipad':
        return <Tablet className="h-4 w-4 text-blue-400" />
      default:
        return <Monitor className="h-4 w-4 text-muted-foreground" />
    }
  }

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text)
    } catch (error) {
      console.error('Failed to copy to clipboard:', error)
    }
  }

  const filteredEvents = events.filter(event => {
    const matchesSearch = 
      event.uniqueId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.ip?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.emailCaptured?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.isp?.toLowerCase().includes(searchTerm.toLowerCase())
    
    if (eventFilter === 'all') return matchesSearch
    return matchesSearch && event.status === eventFilter
  })

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Activity className="h-8 w-8 text-yellow-400" />
          <div>
            <h1 className="text-2xl font-bold text-foreground">Live Activity</h1>
            <p className="text-muted-foreground">Real-time tracking events and user interactions</p>
            <p className="text-muted-foreground text-sm">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch
              checked={autoRefresh}
              onCheckedChange={setAutoRefresh}
              id="auto-refresh"
            />
            <Label htmlFor="auto-refresh" className="text-foreground">Auto-refresh</Label>
          </div>
          
          <Button
            onClick={fetchEvents}
            variant="outline"
            size="sm"
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by unique ID, IP, email, location..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-input border-border text-foreground"
          />
        </div>
        
        <Select value={eventFilter} onValueChange={setEventFilter}>
          <SelectTrigger className="w-48 bg-input border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-popover border-border">
            <SelectItem value="all">All Events</SelectItem>
            <SelectItem value="Open">Open</SelectItem>
            <SelectItem value="Redirected">Redirected</SelectItem>
            <SelectItem value="On Page">On Page</SelectItem>
            <SelectItem value="Blocked">Blocked</SelectItem>
            <SelectItem value="Bot">Bots</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Activity Table */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-foreground flex items-center gap-2">
            Advanced Live Tracking Events
            <Badge variant="outline" className="border-primary text-primary">
              {filteredEvents.length} events
            </Badge>
          </CardTitle>
          <CardDescription className="text-muted-foreground">
            Comprehensive real-time tracking with detailed user information and email capture
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground mt-2">Loading events...</p>
            </div>
          ) : filteredEvents.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                No tracking events found. Create a tracking link to start collecting data.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border">
                    <TableHead className="text-muted-foreground">TIMESTAMP</TableHead>
                    <TableHead className="text-muted-foreground">UNIQUE ID</TableHead>
                    <TableHead className="text-muted-foreground">IP ADDRESS</TableHead>
                    <TableHead className="text-muted-foreground">LOCATION</TableHead>
                    <TableHead className="text-muted-foreground">STATUS</TableHead>
                    <TableHead className="text-muted-foreground">USER AGENT</TableHead>
                    <TableHead className="text-muted-foreground">ISP</TableHead>
                    <TableHead className="text-muted-foreground">EMAIL CAPTURED</TableHead>
                    <TableHead className="text-muted-foreground">ACTIONS</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEvents.map((event) => (
                    <TableRow key={event.id} className="border-border hover:bg-accent/50">
                      <TableCell className="text-foreground">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <div className="text-sm">
                            <div>{event.timestamp}</div>
                            <div className="text-xs text-muted-foreground">
                              Session: {event.sessionDuration}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell className="text-foreground">
                        <div className="space-y-1">
                          <code className="bg-muted px-2 py-1 rounded text-xs block">
                            {event.uniqueId}
                          </code>
                          <div className="text-xs text-muted-foreground">
                            Link: {event.linkId}
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell className="text-foreground">
                        <div className="flex items-center gap-2">
                          <Globe className="h-4 w-4 text-blue-400" />
                          <div>
                            <div className="font-mono text-sm">{event.ip}</div>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              {getDeviceIcon(event.device)}
                              <span>{event.device}</span>
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell className="text-foreground">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-green-400" />
                          <div className="text-sm">
                            <div className="font-medium">{event.city}, {event.region}</div>
                            <div className="text-xs text-muted-foreground">
                              {event.zipCode}, {event.country}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell>
                        <div className="space-y-2">
                          {getStatusBadge(event.status)}
                          <div className="text-xs text-muted-foreground max-w-32">
                            {event.detailedStatus}
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell className="text-foreground">
                        <div className="text-sm max-w-48">
                          <div className="font-medium">{event.browser}</div>
                          <div className="text-xs text-muted-foreground truncate" title={event.userAgent}>
                            {event.os}
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell className="text-foreground">
                        <div className="flex items-center gap-2">
                          <Wifi className="h-4 w-4 text-purple-400" />
                          <div className="text-sm max-w-32">
                            <div className="font-medium">{event.isp}</div>
                            <div className="text-xs text-muted-foreground truncate" title={event.ispDetails}>
                              {event.ispDetails}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      
                      <TableCell className="text-foreground">
                        {event.emailCaptured ? (
                          <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4 text-green-400" />
                            <div className="text-sm">
                              <div className="font-medium text-green-400">{event.emailCaptured}</div>
                              {event.conversionValue > 0 && (
                                <div className="text-xs text-muted-foreground">
                                  Value: ${event.conversionValue}
                                </div>
                              )}
                            </div>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">No email captured</span>
                        )}
                      </TableCell>
                      
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(event.uniqueId)}
                            className="h-8 w-8 p-0"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0"
                          >
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default LiveActivity

