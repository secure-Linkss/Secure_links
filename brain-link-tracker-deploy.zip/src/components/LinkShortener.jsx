import { useState, useEffect } from 'react'

const LinkShortener = () => {
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    fetchLinks()
  }, [])

  const fetchLinks = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/links', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setLinks(data.links || [])
      } else {
        console.error('Failed to fetch links')
      }
    } catch (error) {
      console.error('Error fetching links:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)
    await fetchLinks()
    setRefreshing(false)
  }

  const mockLinks = [
    {
      id: 1,
      shortUrl: 'https://blt.ly/abc123',
      originalUrl: 'https://example.com/very-long-url-that-needs-shortening',
      campaign: 'Summer Sale 2024',
      clicks: 1250,
      visitors: 820,
      created: '2024-01-15',
      expiry: '2024-12-31',
      status: 'Active'
    },
    {
      id: 2,
      shortUrl: 'https://blt.ly/xyz789',
      originalUrl: 'https://blog.example.com/how-to-improve-conversion-rates',
      campaign: null,
      clicks: 890,
      visitors: 620,
      created: '2024-01-12',
      expiry: null,
      status: 'Active'
    },
    {
      id: 3,
      shortUrl: 'https://blt.ly/def456',
      originalUrl: 'https://shop.example.com/special-offer-winter-sale',
      campaign: 'Winter Promotion',
      clicks: 2340,
      visitors: 1820,
      created: '2024-01-10',
      expiry: '2024-02-29',
      status: 'Active'
    },
    {
      id: 4,
      shortUrl: 'https://blt.ly/old123',
      originalUrl: 'https://example.com/expired-promotion',
      campaign: null,
      clicks: 450,
      visitors: 300,
      created: '2023-12-01',
      expiry: '2024-01-01',
      status: 'Expired'
    }
  ]

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text)
    // You could add a toast notification here
  }

  return (
    <div className="p-6 space-y-6 bg-slate-900 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 bg-blue-400 rounded-lg flex items-center justify-center">
            <span className="text-slate-900 font-bold">✂️</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Link Shortener</h1>
            <p className="text-slate-400">Create and manage short links</p>
          </div>
        </div>
        
        <button 
          onClick={() => setShowCreateModal(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium"
        >
          ✂️ Create Short Link
        </button>
      </div>

      {/* Compact Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <span className="text-blue-400 text-lg">🔗</span>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Total Links</p>
              <p className="text-xl font-bold text-white">4</p>
              <p className="text-xs text-green-400">+2 this week</p>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <span className="text-green-400 text-lg">👆</span>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Total Clicks</p>
              <p className="text-xl font-bold text-white">4.9K</p>
              <p className="text-xs text-green-400">+15.3%</p>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <span className="text-purple-400 text-lg">✅</span>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Active Links</p>
              <p className="text-xl font-bold text-white">3</p>
              <p className="text-xs text-slate-400">1 expired</p>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-orange-500/20 rounded-lg">
              <span className="text-orange-400 text-lg">📊</span>
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Avg. CTR</p>
              <p className="text-xl font-bold text-white">74.0%</p>
              <p className="text-xs text-green-400">+5.2%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <div className="absolute left-3 top-3 h-4 w-4 bg-slate-400 rounded"></div>
          <input
            placeholder="Search by original URL, short code, or campaign name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-600 text-white rounded-lg focus:border-blue-500 focus:outline-none"
          />
        </div>
        <select className="w-48 bg-slate-800 border border-slate-600 text-white rounded-lg px-4 py-2.5 focus:border-blue-500 focus:outline-none">
          <option value="all">All Links</option>
          <option value="active">Active</option>
          <option value="expired">Expired</option>
          <option value="campaign">With Campaign</option>
        </select>
        <button className="px-4 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-lg">
          📥 Export CSV
        </button>
      </div>

      {/* Links Table */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg overflow-hidden">
        <div className="p-6 border-b border-slate-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white">Link Shortener Dashboard</h3>
              <p className="text-slate-400">4 links found</p>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm">
                📊 Analytics
              </button>
              <button className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-lg text-sm">
                🔄 Bulk Actions
              </button>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-700/50">
              <tr>
                <th className="text-left text-slate-300 p-4 font-medium">Short Link</th>
                <th className="text-left text-slate-300 p-4 font-medium">Original URL</th>
                <th className="text-left text-slate-300 p-4 font-medium">Performance</th>
                <th className="text-left text-slate-300 p-4 font-medium">Campaign</th>
                <th className="text-left text-slate-300 p-4 font-medium">Status</th>
                <th className="text-left text-slate-300 p-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="text-center text-slate-400 py-12">
                    <div className="animate-spin h-8 w-8 border-2 border-blue-400 border-t-transparent rounded-full mx-auto mb-3"></div>
                    Loading links...
                  </td>
                </tr>
              ) : (
                mockLinks.map((link) => (
                  <tr key={link.id} className="border-b border-slate-700 hover:bg-slate-700/30 transition-colors">
                    <td className="p-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <code className="bg-slate-700 text-blue-400 px-2 py-1 rounded text-sm font-mono">
                            {link.shortUrl}
                          </code>
                          <button 
                            onClick={() => copyToClipboard(link.shortUrl)}
                            className="p-1 bg-slate-600 hover:bg-slate-500 text-white rounded transition-colors"
                            title="Copy"
                          >
                            <span className="text-xs">📋</span>
                          </button>
                        </div>
                        <p className="text-xs text-slate-400">Created: {link.created}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="max-w-xs">
                        <p className="text-white text-sm truncate" title={link.originalUrl}>
                          {link.originalUrl}
                        </p>
                        <p className="text-xs text-slate-400">
                          {link.expiry ? `Expires: ${link.expiry}` : 'Never expires'}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono text-sm">{link.clicks.toLocaleString()}</span>
                          <span className="text-xs text-slate-400">clicks</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-white font-mono text-sm">{link.visitors.toLocaleString()}</span>
                          <span className="text-xs text-slate-400">visitors</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      {link.campaign ? (
                        <span className="inline-flex items-center gap-1 bg-purple-500/20 text-purple-400 px-2 py-1 rounded-full text-sm">
                          📊 {link.campaign}
                        </span>
                      ) : (
                        <span className="text-slate-500 text-sm">No campaign</span>
                      )}
                    </td>
                    <td className="p-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-sm font-medium ${
                        link.status === 'Active' 
                          ? 'bg-green-500/20 text-green-400' 
                          : 'bg-red-500/20 text-red-400'
                      }`}>
                        <div className={`h-2 w-2 rounded-full ${
                          link.status === 'Active' ? 'bg-green-400' : 'bg-red-400'
                        }`}></div>
                        {link.status}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-1">
                        <button className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors" title="Analytics">
                          <span className="text-sm">📊</span>
                        </button>
                        <button className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors" title="Edit">
                          <span className="text-sm">✏️</span>
                        </button>
                        <button className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors" title="QR Code">
                          <span className="text-sm">📱</span>
                        </button>
                        <button className="p-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors" title="Share">
                          <span className="text-sm">🔗</span>
                        </button>
                        <button className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors" title="Delete">
                          <span className="text-sm">🗑️</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Actions Footer */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">Most Clicked</p>
              <p className="text-lg font-bold text-white">blt.ly/def456</p>
              <p className="text-xs text-green-400">2,340 clicks</p>
            </div>
            <div className="h-8 w-8 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-green-400">🏆</span>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">Best CTR</p>
              <p className="text-lg font-bold text-white">77.8%</p>
              <p className="text-xs text-blue-400">blt.ly/def456</p>
            </div>
            <div className="h-8 w-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-blue-400">📈</span>
            </div>
          </div>
        </div>
        
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">Recent Activity</p>
              <p className="text-lg font-bold text-white">12</p>
              <p className="text-xs text-purple-400">clicks today</p>
            </div>
            <div className="h-8 w-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="text-purple-400">⚡</span>
            </div>
          </div>
        </div>
      </div>

      {/* Create Link Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-white">Create Short Link</h3>
              <button 
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Original URL
                </label>
                <input
                  placeholder="https://example.com/your-long-url"
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 text-white rounded-lg focus:border-blue-500 focus:outline-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Custom Short Code (Optional)
                </label>
                <input
                  placeholder="my-custom-link"
                  className="w-full px-3 py-2 bg-slate-700 border border-slate-600 text-white rounded-lg focus:border-blue-500 focus:outline-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Campaign (Optional)
                </label>
                <select className="w-full px-3 py-2 bg-slate-700 border border-slate-600 text-white rounded-lg focus:border-blue-500 focus:outline-none">
                  <option value="">No Campaign</option>
                  <option value="summer-sale">Summer Sale 2024</option>
                  <option value="winter-promo">Winter Promotion</option>
                </select>
              </div>
              
              <div className="flex gap-3 pt-4">
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg"
                >
                  Cancel
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">
                  Create Link
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default LinkShortener

